<?php
namespace Admin\Controller;
use Think\Controller;

class IndexController extends Controller {
    public function index(){

        //$goods=new \Model\EnglishModel();
        //dump($goods);

        //$model=D('news');
        if($_GET['id']==29)
        {
        $model=new \Model\NewsModel();

        //$model ->where('id >100');
        //$model ->limit(5);

        $info = $model->select();
        //dump($info);

        $this -> assign('info',$info);

        $this->show();
        }
        else
          $this -> redirect('Manager/login', array("id" => $id), 2, '请登录了再来，我送你回家，不要盲目操作');
    }



}