<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Verify;
class ManagerController extends Controller {
	function login() {
        if(!empty($_POST)){
            $vry = new Verify();

            if($vry -> check($_POST['yanzheng'])){
                //校正用户名和密码
                //dump($_POST);
                $userpwd = array(
                    'username' => $_POST['username'],
                    'password' => $_POST['password'],
                );
                $info = D('admin') -> where($userpwd)->find();
                dump($info);
                if($info){
                        //session持久化用户信息，页面跳转
                        session('name'.$info['name']);
                        session('lastloginip'.$info['lastloginip']);
                        $this -> redirect('Index/index?id=29');
                }else{
                        echo "用户名或密码错误";
                }
            }
            else{
                echo "验证码错误";
            }
        }
		$this -> display();

	}

    //退出系统
    function logout(){
        //清除session、跳转到Nanager/login
        session(null);
        $this -> redirect('Manager/login');


    }




//生成验证码
    function verifyImg(){
        $cfg = array(
            'imageH' => 40,
            'imageW' => 120,
            'length' =>4,
            'fontSize' => 16,
            'fontttf' => '4.ttf',


        );
        $very = new \Think\Verify($cfg);
        $very -> entry();

    }



}
