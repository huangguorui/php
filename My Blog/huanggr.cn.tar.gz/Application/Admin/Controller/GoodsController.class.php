<?php
namespace Admin\Controller;
use Think\Controller;

class GoodsController extends Controller {

	function showlist() {


		$goods = D('news');

		$cnt = $goods -> count(); //获得总条数，sum, max.avg min

		$per = 7;
		//echo $cnt;

		//2.实例化分页类对象
		$page_obj = new \Tools\Page($cnt,$per);

		//3.制作一条sql语句
		//$page_obj -> limit:分页工具类会根据当前页面把limit，偏移量，长度给封装好
		$sql = "select * from tb_news order by id desc ".$page_obj ->limit;

		$info = $goods ->query($sql);
		//4.制作页码列表,根据数组传入的值进行循环
		$pagelist = $page_obj -> fpage(array(3,4,5,6,7,8));

		$this -> assign('pagelist',$pagelist);
		$this -> assign('info', $info);
		$this -> display();

		//dump($z);
		//$info = $goods -> select();
	}

	function tianjia() {
if($_GET['id']==29){


		//功能有，展示表单，收集表单信息
		$goods = D('news');
		if (!empty($_POST)) {
			dump($_FILES);

			if($_FILES['file']['error']===0){

				$cfg = array(
					'rootPath' => "./Public/Upload/",
				);
				//设置附件的存储位置
				$up = new \Think\Upload($cfg);

				//如果附件上传成功
				$z = $up ->uploadOne($_FILES['file']);
				dump($z);
				$bigpicname = $up -> rootPath.$z['savepath'].$z['savename'];
				$_POST['photos'] = $bigpicname;
		}
		//exit;
		//还要添加一下当前的时间
			//$data = $goods -> create();
			$_POST['date']=time();
			$z = $goods -> add($_POST);
			if ($z) {
				//$this->redirect(地址（地址分组、控制器、操作方法），参数，间隔时间，提示信息)；
				$this -> redirect('Admin/Goods/tianjia?id=29', array(), 2, '添加文章成功');

			} else {
				$this -> redirect('/tianjia', array(), 2, '添加文章失败');

			}

			//dump($_POST);

		} else {
			$this -> show();

		}


}else{
        $this -> redirect('Manager/login', array("id" => $id), 2, '请登录了再来，再见兄弟，不要盲目操作');

}



	}

	//以下upd方法每次访问的时候必须要有id
	function upd($id) {
		$goods = D('news');
		if (!empty($_POST)) {
			dump($_POST);
			$z = $goods -> save($_POST);
			if ($z) {
				//$this->redirect(地址（地址分组、控制器、操作方法），参数，间隔时间，提示信息)；
				$this -> redirect('Goods/tianjia', array("title" => "thinkkuangjia"), 2,'添加文章成功');
			} else {
				$this -> redirect('upd', array("id" => $id), 2, '文章添加失败');
			}
		} else {
			//方法一
			//find()方法，通过一位数组返回一条记录信息
			$info = $goods -> find($id);
			dump($info);
			$this -> assign('info', $info);
			$this -> show();
		}


	}

	function del($id){
		$goods = D('news');
		dump($id);
		$goods->where("id=$id")->delete();
		$this -> redirect('showlist', array("title" => "kuangjia.asp"), 2, "该说说已经成功删除");


	}






}
