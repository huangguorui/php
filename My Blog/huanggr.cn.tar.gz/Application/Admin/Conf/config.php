<?php
return array(
	//'配置项'=>'配置值'

       'DB_TYPE'               =>  'mysql',     // 数据库类型
    'DB_HOST'               =>  'localhost', // 服务器地址
    'DB_NAME'               =>  'dd_bllog',          // 数据库名
    'DB_USER'               =>  'dd_bllog',      // 用户名
    'DB_PWD'                =>  '123456',          // 密码
    'DB_PORT'               =>  '3306',        // 端口
    'DB_PREFIX'             =>  'tb_',    // 数据库表前缀



    //开启模板smrt引擎
    'TMPL_ENGINE_TYPE'      =>  'smarty',     // 默认模板引擎 以下设置仅对使用Think模板引擎有效

/*定义的常量，需要的时候直接可以使用*/
define('aa', '123456'),
define('CSS_URL', 'http://localhost/1201/Public/css/' ),
    /*使用smarty换标签*/
'TMPL_ENGINE_CONFIG'=>array(
    //'left_delimiter' => '<%%%',
    //'right_delimiter'=> '%%%>',
    ),

);