<?php /* Smarty version Smarty-3.1.6, created on 2018-01-31 10:45:44
         compiled from "./Application/Home/View/Index/index.html" */ ?>
<?php /*%%SmartyHeaderCode:17330146225a712dd8d067b1-23356779%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd5c4efec70a0a967b5684ac66a58dba13edd61fd' => 
    array (
      0 => './Application/Home/View/Index/index.html',
      1 => 1517232645,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17330146225a712dd8d067b1-23356779',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'info' => 0,
    'v' => 0,
    'pagelist' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a712dd8d78b3',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a712dd8d78b3')) {function content_5a712dd8d78b3($_smarty_tpl) {?>
<style type="text/css">
.text-img img {
     transition:all .6s;
}
.text-img {
    width: 220px;
    height: 160px;
    margin-top:7px;
    overflow:hidden;
    float: left;
}
.text-img:hover img {
    -webkit-transform: scale(1.2) rotate(5deg);
       -moz-transform: scale(1.2) rotate(5deg);
        -ms-transform: scale(1.2) rotate(5deg);
         -o-transform: scale(1.2) rotate(5deg);
            transform: scale(1.2) rotate(5deg);
</style>
    <!-- 正文区域start -->
    <div class="continar">
    	 <div class="continar-left">
    	 	 <div class="continar-left-top">
    	 	 	 <h1>
	 	 	          <a href="javascript:;">
	 	 	        	<span>【关于兼容性的通知】</span>支持各大主流浏览器
	 	 	          </a>
    	 	 	 </h1>
    	 	 	 <p>
    	 	 	     经过夜以继日的修复，ie10以及以下会直接弹出对话框提示升级，由于版本新旧问题，可能还是会有问题,在随后的时间里，我们慢慢来。
    	 	 	 </p>
    	 	 </div>

<?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['info']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
    	 	 <div class="text">
    	 	     <div class="text-img" >
                     <a href="<?php echo @__CONTROLLER__;?>
/details/id/<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
.html"><img src="<?php echo @moban;?>
<?php echo $_smarty_tpl->tpl_vars['v']->value['photos'];?>
" alt="" width='100%' height='100%' border='0' style="margin-top:0"></a>
                 </div>
    	 	     <!-- 左侧图片 -->
    	 	     <div class="text_right">
	    	 	 	 <h2>
		    	 	 	 <a class="cat" href="#">HTML/CSS<i></i></a>
		    	 	 	 <a  href='index.php/Home/new/<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
.html' style="width:411px;height:28px;overflow:hidden;display:inline-block;text-align:center"><?php echo $_smarty_tpl->tpl_vars['v']->value['title'];?>
</a>
	    	 	 	 </h2>
	    	 	 	 <div class="entry-meta">
	    	 	 	     <a href="#">前端博客
	    	 	 	     </a>
	    	 	 	     <i class="space">•</i>
	    	 	 	     <a href="#">前端开发资讯</a>
	    	 	 	     <i class="space">•</i>
	    	 	 	     作者：管理员
	    	 	 	     <a href="#" class="comments-number">
	    	 	 	         <span></span>
	    	 	 	     </a>
	    	 	 	 </div>
	    	 	 	 <h3 style="overflow:hidden" class="h3-img">
	    	 	 	    <div>
                            <?php echo $_smarty_tpl->tpl_vars['v']->value['text'];?>

                        </div>
	    	 	 	 </h3>
	    	 	 	 <a class="read-more" rel="nofollow"  href='index.php/Home/new/<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
.html' title="20161030 前端开发日报">阅读全文
	    	 	 	 </a>
	    	 	 	 <p class="l">
						<span>&nbsp;<i class="iconfont">&#xe601;</i>发布日期：<php> <?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['v']->value['date'];?>
<?php $_tmp1=ob_get_clean();?><?php echo date('Y-m-d ',$_tmp1);?>
</php></span>
						<span>&nbsp;<i class="iconfont">&#xe605;浏览数：</i><?php echo $_smarty_tpl->tpl_vars['v']->value['browse'];?>
</span>
						<span class="comm">&nbsp;<a href="index.php/Home/new/<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
.html"><i class="iconfont">&#xe63d;</i>评论数：<span id = "url::http://www.huanggr.cn/index.php/Home/new/<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
.html" class = "cy_cmt_count" ></span></a></span>
						<span class="r"></span>
					 </p>
	    	 	 	 <em><a href="index.php/Home/new/<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
.html"><span style="color:#fff" id = "url::url::http://www.huanggr.cn/index.php/Home/new/<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
.html" class = "cy_cmt_count" ></span></a></em>
    	 	 	 </div>
    	 	 </div>
<?php } ?>
<!--<?php echo @__CONTROLLER__;?>
/details/id/<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
.html -->
 <!-- 文章end -->
    <!-- 底部分页开始 -->
    <div class="pagination">
        <ul>
            <?php echo $_smarty_tpl->tpl_vars['pagelist']->value;?>

        </ul>
    </div>
    <!-- 底部分页结束 -->
 </div>
    	 <!-- 左侧区域结束 -->

<?php }} ?>