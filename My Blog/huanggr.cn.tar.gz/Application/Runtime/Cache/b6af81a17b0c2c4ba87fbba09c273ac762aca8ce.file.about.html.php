<?php /* Smarty version Smarty-3.1.6, created on 2018-01-31 22:33:32
         compiled from "./Application/Home/View/Index/about.html" */ ?>
<?php /*%%SmartyHeaderCode:11790504885a71d3bc81b446-89814221%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b6af81a17b0c2c4ba87fbba09c273ac762aca8ce' => 
    array (
      0 => './Application/Home/View/Index/about.html',
      1 => 1515070256,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11790504885a71d3bc81b446-89814221',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a71d3bc867ff',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a71d3bc867ff')) {function content_5a71d3bc867ff($_smarty_tpl) {?><!-- 正文区域start -->
    <div class="continar">
         <div class="continar-left">
             <h4>站长介绍</h4>
             <ul class="clearfix">
                    <li class="photo">
                        <a href="#" title="李俊">
                            <img src="images/IMG_0028.JPG" width="150" alt="手机里面没有找到好看的图片" title="瑞">
                        </a>
                    </li>
                    <li><span>姓名：瑞</span><span>名族：大汉</span></li>
                    <li><span>星座：</span><span>学历：大专</span></li>
                    <li><span>籍贯：湖北省</span><span>专业：网络前端</span></li>
                    <li><span>未来从事的职业：Web前端开发工程师</span></li>
                    <li>
                        <span style="width:70%">
                            原创座右铭：天天做出好东西，哈哈哈哈。
                        </span>
                    </li>
                    <li style="margin-top:10px; clear: both;"><span>自我说明：</span></li>

                    <li class="index">
                        有些东西在如何如何的好那也只能是兴趣，而不应该是爱好，心中应该有一个梦，可望可及，它可以理解为一种信念，也可理解为一种追求。
                    </li>
                </ul>
                <h4>博客介绍</h4>
                <p>
                    爱前端个人博客，是我建的第一个人博客网站，这里是我学习前端写笔记、心得的地方，抒发自己情感的地方，我会慢慢来经营我的人博客网站，怀着自己的梦想，从这里起飞，远航。
                </p>
                <p>
                    此网站采用TP+MSQL进行设计，，前端模块运用了大量css3运动，（目前完善了登录注册以及留言回复，文章发布等功能，后期功能将增加响应式设计，以及性能优化，）整体页面华丽的同时也会暗藏bug（说实在的，问题真滴多），尽快本人测试多次，但难免在众多设备或者不同人不同见解任有所不足之处，如有好的意见欢迎给我留言，博客会适当改进，慢慢改版。
                </p>
                <p>
                    网址:<a href="http://www.huanggr.cn" target="_blank">www.huanggr.cn</a>
                    <a href="https://cloud.tencent.com/" target="_blank">购买域名</a>
                </p>
                <p>
                    服务器：腾讯云服务器
                    <a href="https://cloud.tencent.com/"  target="_blank">购买服务器</a>
                </p>
                <p>
                    程序：ThinkPHP+MYSQL
                </p>
                <h2 style="text-indent: 2em">联系方式</h2>
                <ul class="bon-1">
                    <li>QQ：2315684336</li>
                    <li>E-mail：2315684336@qq.com</li>
                </ul>
         </div>
         <!-- 左侧区域结束 -->


<?php }} ?>