<?php /* Smarty version Smarty-3.1.6, created on 2018-01-31 20:08:57
         compiled from "./Application/Home/View/User/login.html" */ ?>
<?php /*%%SmartyHeaderCode:1649658225a71b1d93d3943-70203638%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '528eb25b2073e9055b2eab3085b51ff3b2907925' => 
    array (
      0 => './Application/Home/View/User/login.html',
      1 => 1512470308,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1649658225a71b1d93d3943-70203638',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'errorInfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a71b1d9498a0',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a71b1d9498a0')) {function content_5a71b1d9498a0($_smarty_tpl) {?><!doctype html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="https://cdn.bootcss.com/bootstrap/3.0.2/css/bootstrap.min.css">
    <script src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdn.bootcss.com/bootstrap/3.0.2/js/bootstrap.min.js"></script>
	<title>用户登录</title>
<style type="text/css">
            textarea {
           resize:none;
           width: 300px;
           height: 100px;
        }
        .form1 {
            width: 400px;
            height: auto;
            /*background: red;*/
            position: absolute;
            left:50%;
            top: 50%;
            padding:20px;
            margin-left:-220px;
            overflow:hidden;
            border-radius:5px;
            box-shadow: 0 0 1px 1px black;
        }

        #sub-btn {
            display: block;
            margin:20px auto;
        }
        input[name=yanzheng]{
        	width:150px;
        	float: left;
        	margin-right:10px;
        }
</style>
</head>
<body>

<form class="form1" action="<?php echo @__SELF__;?>
" method="post" autocomplete="off" >
    <h3 style="text-align:center">用户登录</h3>
    <div class="form-group">
        <label for="user">用户名：</label>
        <input type="text" class="form-control" id="user" name="username" placeholder="输入一个用户名吧" required="required">
        <span style="color:red"><?php echo $_smarty_tpl->tpl_vars['errorInfo']->value['username'];?>
</span>
    </div>
    <div class="form-group">
        <label for="tel">密码：</label>
        <input type="password" class="form-control" id="password" placeholder="请输入密码"  required="required" name="password" >
        <span style="color:red"><?php echo $_smarty_tpl->tpl_vars['errorInfo']->value['password'];?>
</span>

    </div>
    <div class="form-group">

        <input type="password" class="form-control" id="password" placeholder="请输入验证码"  required="required" name="yanzheng">
    <img src="<?php echo @__CONTROLLER__;?>
/verifyImg" width="180" height="50" onclick="this.src='<?php echo @__CONTROLLER__;?>
/verifyImg/'+Math.random()" />
    </div>


  <input type="submit" class="btn  btn-primary"  id="sub-btn" value="点击登陆">
</form>
</body>
</html>
<script type="text/javascript">
    $('form').css("margin-top",(-$('form').height()/2-20));

window.onresize=function(){
    $('form').css("margin-top",(-$('form').height()/2-20));
}
</script>





<?php }} ?>