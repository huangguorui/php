<?php /* Smarty version Smarty-3.1.6, created on 2018-02-02 15:32:35
         compiled from "./Application/Admin/View/Goods/tianjia.html" */ ?>
<?php /*%%SmartyHeaderCode:8129220765a741413f11184-82098640%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dd38ea81eb47ee3cacf9d0b8f4fb1b421c722a85' => 
    array (
      0 => './Application/Admin/View/Goods/tianjia.html',
      1 => 1512808642,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8129220765a741413f11184-82098640',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'info' => 0,
    'v' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a74141402137',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a74141402137')) {function content_5a74141402137($_smarty_tpl) {?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>这里是添加页面</title>
<style type="text/css">
        *{
            margin: 0;
            padding: 0;
        }
        img{
            border:0;
        }
        ol, ul ,li{ list-style: none; }
        textarea {
            width: 700px;
            height: 300px;
        }
        input {
            width: 300px;
            height: 50px;
            border-radius:5%;
            margin:30px 0;
        }
    </style>
</head>
<body>

<h1>博客内容添加页面</h1>
    <form action="<?php echo @__SELF__;?>
" method="post" enctype="multipart/form-data">
        <label>请输入标题：
            <input type="text" name="title" />
        </label><br />
        <label>请输入文章内容：
            <textarea type="text" name="text"></textarea>
        </label><br />
        <label>请输入点击量：
            <input type="text" name="browse" />
        </label><br />

        <label>
        	<input type="file" name="file" value="" multipart>
        </label><br />
        <input type="submit" name="" value="发布">


    </form>
<table border="1">
    <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['info']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
<tr>
    <td><?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
</td>
    <td><?php echo $_smarty_tpl->tpl_vars['v']->value['title'];?>
</td>
    <td><?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
</td>
    <td><?php echo $_smarty_tpl->tpl_vars['v']->value['date'];?>
</td>
    <td><?php echo $_smarty_tpl->tpl_vars['v']->value['browse'];?>
</td>
    <td><?php echo $_smarty_tpl->tpl_vars['v']->value['photos'];?>
</td>
    <td><a href="#">修改</a></td>
    <td><a href="#">删除</a></td>

</tr>




<?php } ?>
</table>
</body>
</html><?php }} ?>