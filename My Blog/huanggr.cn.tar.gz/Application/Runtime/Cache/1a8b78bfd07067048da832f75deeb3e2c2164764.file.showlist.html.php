<?php /* Smarty version Smarty-3.1.6, created on 2018-02-02 15:32:25
         compiled from "./Application/Admin/View/Goods/showlist.html" */ ?>
<?php /*%%SmartyHeaderCode:12999589065a741409651d13-20616281%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1a8b78bfd07067048da832f75deeb3e2c2164764' => 
    array (
      0 => './Application/Admin/View/Goods/showlist.html',
      1 => 1512806782,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12999589065a741409651d13-20616281',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'info' => 0,
    'v' => 0,
    'pagelist' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a7414096bf2a',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a7414096bf2a')) {function content_5a7414096bf2a($_smarty_tpl) {?><!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="UTF-8" />
		<title>展示页面</title>
  <link rel="stylesheet" href="<?php echo @CSS_URL;?>
index.css">
	</head>
	<body>
		<h1>这里是展示页面</h1>
		<table border="1">
			<?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['info']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
			<tr>
				<td><?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['v']->value['title'];?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['v']->value['date'];?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['v']->value['browse'];?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['v']->value['photos'];?>
</td>
				<td>
					<a href="<?php echo @__CONTROLLER__;?>
/upd/id/<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
">修改</a>
				</td>
				<td>
					<a href="<?php echo @__CONTROLLER__;?>
/del/id/<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
">删除</a>
				</td>

			</tr>

			<?php } ?>
			<tr>
				<div class="pagination">
					<ul>
						<?php echo $_smarty_tpl->tpl_vars['pagelist']->value;?>

					</ul>
				</div>
			</tr>
		</table>
	</body>

</html><?php }} ?>