<?php /* Smarty version Smarty-3.1.6, created on 2018-02-02 15:32:29
         compiled from "./Application/Admin/View/Goods/upd.html" */ ?>
<?php /*%%SmartyHeaderCode:6296084425a74140d6425d1-67876817%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '434ffbc8588746a0de27deeb7972eee06ad63c8c' => 
    array (
      0 => './Application/Admin/View/Goods/upd.html',
      1 => 1512807002,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6296084425a74140d6425d1-67876817',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'info' => 0,
    'v' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a74140d681b4',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a74140d681b4')) {function content_5a74140d681b4($_smarty_tpl) {?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>这里是修改页面</title>

</head>
<body>
    <h1>这里是修改页面</h1>
    <h1><?php echo $_smarty_tpl->tpl_vars['info']->value['title'];?>
</h1>
<table border="1">
<tr>
<form action="<?php echo @__SELF__;?>
" method="post" accept-charset="utf-8">



    <!--<td><input type="text" name="" value="<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
"  /></td> -->
    <td><input type="text" name="title" value="<?php echo $_smarty_tpl->tpl_vars['info']->value['title'];?>
"  /></td>
    <td><input type="text" name="id" value="<?php echo $_smarty_tpl->tpl_vars['info']->value['id'];?>
"  /></td>
    <td><input type="text" name="date" value="<?php echo $_smarty_tpl->tpl_vars['info']->value['date'];?>
"  /></td>
    <td><input type="text" name="browse" value="<?php echo $_smarty_tpl->tpl_vars['info']->value['browse'];?>
"  /></td>
    <td><input type="text" name="photos" value="<?php echo $_smarty_tpl->tpl_vars['info']->value['photos'];?>
"  /></td>
    <td><input type="submit" name="" value="修改" /></td>
</form>
</tr>

</table>
</body>
</html><?php }} ?>