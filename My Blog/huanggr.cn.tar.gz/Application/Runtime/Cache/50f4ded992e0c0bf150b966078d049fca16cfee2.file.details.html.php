<?php /* Smarty version Smarty-3.1.6, created on 2018-01-31 10:45:47
         compiled from "./Application/Home/View/Index/details.html" */ ?>
<?php /*%%SmartyHeaderCode:19889262805a712ddb1dc007-36455948%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '50f4ded992e0c0bf150b966078d049fca16cfee2' => 
    array (
      0 => './Application/Home/View/Index/details.html',
      1 => 1517227182,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19889262805a712ddb1dc007-36455948',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'info' => 0,
    'v' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a712ddb22bc1',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a712ddb22bc1')) {function content_5a712ddb22bc1($_smarty_tpl) {?>
    <!-- 正文区域start -->
    <div class="continar">
         <div class="continar-left" id="details" style="margin-bottom:520px;">
              <div class="nav-s">
                    <a href="http://huanggr.cn" class="nav-index"><font class="iconfont"></font>首页</a>
                    <a href="#">前端博客</a><a href="#">前端开发资讯</a>
              </div>
              <div class="xiaob">
                          <h1 class="title" id="title" style="font-size:22px;text-align:center;line-height:70px; margin:20px 0 10px 0"><?php echo $_smarty_tpl->tpl_vars['info']->value['title'];?>
</h1>
                          <p class="data-l">
                                <span><font class="iconfont">&#xe601;&nbsp;&nbsp;</font>发布时间：<php> <?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['info']->value['date'];?>
<?php $_tmp1=ob_get_clean();?><?php echo date('Y-m-d ',$_tmp1);?>
</php></span>
                                <span><font class="iconfont">&#xe6e3;&nbsp;&nbsp;</font>管理员</span>

                                <span><font class="iconfont">&#xe605;&nbsp;&nbsp;</font><?php echo $_smarty_tpl->tpl_vars['info']->value['browse'];?>
次浏览</span>
                          </p>
                        <div  id="autoNO" style=" width:100%;height:400px;padding:30px;overflow-x:hidden;overflow-y:auto"><?php echo $_smarty_tpl->tpl_vars['info']->value['text'];?>
</div>

                        <span></span>
              </div>
              <div class="log-text" >
              <p></p>
                    <p class="key-w">
                        <font class="iconfont"></font>标签：<a href="#" rel="tag">前端</a><a href="#" rel="tag">前端</a><a href="#" rel="tag">前端</a>
                    </p>
              <input type="submit" value="点击开启阅读无限制高度模式" onclick="this.style.display='none';autoNO.style.height='auto';">
                <p></p>
                    <p class="text-post" >
                        上一篇：
                        <a title="<?php echo $_smarty_tpl->tpl_vars['info']->value['title'];?>
" href="index.php/Home/new/<?php echo $_smarty_tpl->tpl_vars['v']->value['id']-1;?>
.htm" target="_blank">点击进入上一篇（<?php echo $_smarty_tpl->tpl_vars['info']->value['id']-1;?>
）
                        </a>
                    </p>
                    <p class="text-post">
                        下一篇：
                        <a title="<?php echo $_smarty_tpl->tpl_vars['info']->value['title'];?>
" href="index.php/Home/new/<?php echo $_smarty_tpl->tpl_vars['v']->value['id']+1;?>
.html" >点击进入下一篇（<?php echo $_smarty_tpl->tpl_vars['info']->value['id']+1;?>
）</a>
                    </p>
                <p>点击上一篇下一篇还处于调试阶段，现阶段无法避开id断开的情况</p>
                </div>
                <!-- 评论内容开始 -->
                <ul class="ds-comments">
                  <li></li>
                </ul>

</div>

      <script>
      document.title=title.innerHTML;
      </script>
<?php }} ?>