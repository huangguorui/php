<?php /* Smarty version Smarty-3.1.6, created on 2018-01-31 20:14:33
         compiled from "./Application/Home/View/User/register.html" */ ?>
<?php /*%%SmartyHeaderCode:5486490885a71b3291d4638-45803326%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '59979fb4a6a56c3368aab27ee7cb74bd59c01dde' => 
    array (
      0 => './Application/Home/View/User/register.html',
      1 => 1512292768,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5486490885a71b3291d4638-45803326',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'errorInfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a71b329250e7',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a71b329250e7')) {function content_5a71b329250e7($_smarty_tpl) {?><!doctype html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="https://cdn.bootcss.com/bootstrap/3.0.2/css/bootstrap.min.css">
    <script src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdn.bootcss.com/bootstrap/3.0.2/js/bootstrap.min.js"></script>

	<title>用户注册</title>

<style type="text/css">
            textarea {
           resize:none;
           width: 300px;
           height: 100px;
        }
        .form1 {
            width: 400px;
            height: auto;
            /*background: red;*/
            position: absolute;
            left:50%;
            top: 50%;
            padding:20px;
            margin-left:-220px;
            overflow:hidden;
            border-radius:5px;
            box-shadow: 0 0 1px 1px black;
        }

        #sub-btn {
            display: block;
            margin:20px auto;
        }


</style>
</head>
<body>
<form class="form1" action="<?php echo @__SELF__;?>
" method="post" autocomplete="off" id="from">
    <h3 style="text-align:center">用户注册</h3>
    <div class="form-group">
        <label for="user">用户名：</label>
        <input type="text" class="form-control" id="user" name="username" placeholder="输入一个用户名吧" required="required">
        <span style="color:red"><?php echo $_smarty_tpl->tpl_vars['errorInfo']->value['username'];?>
</span>
    </div>
    <div class="form-group">
        <label for="tel">密码：</label>
        <input type="password" class="form-control" id="password" placeholder="输入一个手机号吧"  required="required" name="password">
        <span style="color:red"><?php echo $_smarty_tpl->tpl_vars['errorInfo']->value['password'];?>
</span>
    </div>
    <div class="form-group">
        <label for="password2">再次输入密码：</label>
        <input type="password" class="form-control" id="password2" placeholder="再次输入密码："  required="required" name="password2">
        <span style="color:red"><?php echo $_smarty_tpl->tpl_vars['errorInfo']->value['password2'];?>
</span>

    </div>
    <div class="form-group">
        <label for="user_email">请输入您的邮箱：</label>
        <input type="email" class="form-control" id="user_email" placeholder="请输入您的邮箱："  required="required" name="user_email">
        <span style="color:red"><?php echo $_smarty_tpl->tpl_vars['errorInfo']->value['user_email'];?>
</span>

    </div>
    <div class="form-group">
        <label for="user_qq">QQ号：</label>
        <input type="number" class="form-control" id="user_qq" placeholder="QQ："  required="required" name="user_qq">
        <span style="color:red"><?php echo $_smarty_tpl->tpl_vars['errorInfo']->value['user_qq'];?>
</span>

    </div>

  <input type="submit" class="btn  btn-primary" id="sub-btn" value="点击注册">
</form>
</body>
</html>
<script type="text/javascript">
    $('form').css("margin-top",(-$('form').height()/2));

window.onresize=function(){
    $('form').css("margin-top",(-$('form').height()/2));
}


</script>





<?php }} ?>