<?php /* Smarty version Smarty-3.1.6, created on 2018-02-02 18:55:08
         compiled from "./Application/Home/View/Index/message.html" */ ?>
<?php /*%%SmartyHeaderCode:16466196355a74438c982344-55706033%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7256c1d5b69901bb89cfb90dc8f42f82d4937bec' => 
    array (
      0 => './Application/Home/View/Index/message.html',
      1 => 1512979142,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16466196355a74438c982344-55706033',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a74438c9aadf',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a74438c9aadf')) {function content_5a74438c9aadf($_smarty_tpl) {?>

    <!-- 正文区域start -->
    <div class="continar">
         <div class="continar-left" id="details">
              <div class="nav-s1" style="background:#f6f6f6; width:100%; margin:0 auto; text-align: center; ">
                    <a href="#" style="font-size:20px; color: #45BCF9">
                    ----------------------- 给我留言 -----------------------</a>
              </div>
              <div class="jy">
                  <p>
                    在这个心灵的驿站里，让我们用真诚善良之心相聚于此，相约明天。我相信我们的明天：太阳会更灿烂、微风更柔和、空气更新鲜。在这个小小空间里，让网络传递着我们的真情，让我们今生共同珍惜来之不易的缘分，共同迎接那美好的明天。让我们一起放飞童真、放飞希望、放飞梦想。让我们对着自己的青春纪念碑，毫无羞愧说一声：青春万岁、理解万岁、友谊万岁。
                  </p>
                  <p>
                    欢迎来到我的博客访问，可以尽情在这里留下您的脚印。。。
                  </p>


                  </div>



              <!-- 留言区域结束 -->
         </div>
         <!-- 左侧区域结束 -->
      <script>
        document.title="我的博客--留言板";
      </script><?php }} ?>