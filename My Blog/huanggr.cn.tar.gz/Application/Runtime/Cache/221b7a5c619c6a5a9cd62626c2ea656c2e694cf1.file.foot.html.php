<?php /* Smarty version Smarty-3.1.6, created on 2018-01-31 10:45:47
         compiled from "./Application/Home/View/Index/foot.html" */ ?>
<?php /*%%SmartyHeaderCode:12541796315a712ddb231072-97968801%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '221b7a5c619c6a5a9cd62626c2ea656c2e694cf1' => 
    array (
      0 => './Application/Home/View/Index/foot.html',
      1 => 1515934569,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12541796315a712ddb231072-97968801',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a712ddb29527',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a712ddb29527')) {function content_5a712ddb29527($_smarty_tpl) {?>         <!-- 右侧区域开始 -->
         <div class="continar-right">
               <aside>
                     <h3>博客介绍</h3>
                     <div class="textwidget">
                        <p class="clearfix">
                            <a href="#" rel="home">前端博客</a> : huanggr.cn，我们关注Web前端开发技术，移动前端开发，前端资讯，同时分享前端资源和工具等，期待你的参与,<a rel="nofollow" target="_blank" href="/about">了解更多..</a>
                        </p>
                        <ul class="social">
                            <li class="weibo">
                               <a href="#" target="_blank" class="top-tip" title="关注新浪微博"></a>
                            </li>
                            <li class="qq">
                               <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=2315684336&site=qq&menu=yes"" rel="nofollow" class="top-tip" title="QQ"></a>
                            </li>
                            <li class="feed">
                               <a target="_blank" href="//shang.qq.com/wpa/qunwpa?idkey=46f7cac0432d354185661d7bf2eb368d567488f8269d4bab83fd7e1a562b1e83" rel="nofollow" class="top-tip" title="加入群" alt="群"></a>



                            </li>
                            <li class="email">
                               <a href="#" target="_blank" rel="nofollow" class="top-tip" title="订阅到qq邮箱"></a>
                            </li>
                            <li class="weixin">
                                <a href="#" target="_blank" rel="nofollow" class="top-tip" title="关注微信"></a>
                            </li>
                        </ul>
                    </div>
               </aside>


         <!-- 右侧区域开始 -->
         <div class="continar-right">
               <!-- 前端日报开始 -->
               <div class="widget">
                   <div class="daily-list">
                        <h3 class="widget-title"><a href="#">前端日报</a></h3>
                        <ul>
                            <li><a rel="bookmark" href="#" title="20161030 前端开发日报"><span class="daily-title">20161030 前端开发日报</span>
                            <h3 class="daily-desc">7个去伪存真的JavaScript面试题；手把手教你打造一个纯 CSS ...</h3>
                            </a></li>
                            <li><a rel="bookmark" href="#" title="20161030 前端开发周报"><span class="daily-title">20161030 前端开发周报</span>
                            <h3 class="daily-desc">一道常被人轻视的前端 JS 面试题；微信小程序最新版102700：新增1...</h3>
                            </a></li>
                            <li><a rel="bookmark" href="#" title="20161029 前端开发日报"><span class="daily-title">20161029 前端开发日报</span>
                            <h3 class="daily-desc">纯CSS的导航栏Tab切换方案；JS 闭包的2W1H；最详细的JavaS...</h3>
                            </a></li>
                            <li><a rel="bookmark" href="#" title="20161028 前端开发日报"><span class="daily-title">20161028 前端开发日报</span>
                            <h3 class="daily-desc">微信小程序最新版102700：新增19个API；前端技术体系大局观；Ja...</h3>
                            </a></li>
                            <li><a rel="bookmark" href="#" title="20161027 前端开发日报"><span class="daily-title">20161027 前端开发日报</span>
                            <h3 class="daily-desc">B 站出品的 HTML5 FLV 播放器；GitHub 指南汇集；为什么...</h3>
                            </a></li>
                            <li><a rel="bookmark" href="#" title="20161026 前端开发日报"><span class="daily-title">20161026 前端开发日报</span>
                            <h3 class="daily-desc">常用的 Web 前端框架汇总；作为前端需要了解的B/S架构；聊聊微信小程...</h3>
                            </a></li>
                        </ul>
                    </div>
               </div>
               <!-- 前端日报结束 -->

               <!-- 技术分类开始 -->
               <div class="classif">
                   <h3>标签云</h3>
                   <div class="items">
                        <a href="#">前端技巧 (61)</a>
                        <a href="#">CSS (52)</a>
                        <a href="#">JavaScript (50)</a>
                        <a href="#">用户体验 (46)</a>
                        <a href="#">设计思路 (43)</a>
                        <a href="#">HTML5 (40)</a>
                        <a href="#">SEO (40)</a>
                        <a href="#">网页设计 (40)</a>
                        <a href="#">CSS3 (37)</a>
                        <a href="#">职业 (34)</a>
                        <a href="#">前端资源 (33)</a>
                        <a href="#">唯品秀 (31)</a>
                        <a href="#">企业公司 (30)</a>
                        <a href="#">浏览器 (28)</a>
                        <a href="#">站长必备 (27)</a>
                        <a href="#">jQuery (22)</a>
                        <a href="#">搜索引擎优化 (22)</a>
                        <a href="#">web开发 (17)</a>
                        <a href="#">兼容 (17)</a>
                        <a href="#">HTML (16)</a>
                        <a href="#">web标准 (16)</a>
                        <a href="#">Google (15)</a>
                        <a href="#">IE9 (15)</a>
                        <a href="#">前端工具 (15)</a>
                        <a href="#">浩子 (15)</a>
                        <a href="#">IE6 (12)</a>
                        <a href="#">网站公告 (12)</a>
                        <a href="#">wordpress (11)</a>
                        <a href="#">CSS3详解 (11)</a>
                        <a href="#">搜索引擎 (10)</a>
                    </div>
               </div>
               <div class="classif">
                   <h3>友情链接</h3>
                   <div class="items">
                        <a href="http://www.118c.club"  target="_blank">老妖的技术栈</a>
                        <a href="">李四的博客</a>
                        <a href="#">王五的博客</a>
                        <a href="#">张六的博客</a>
                        <a href="#">张六的博客</a>
                        <a href="#">张六的博客</a>
                        <a href="#">张六的博客</a>
                        <a href="#">张六的博客</a>
                        <a href="#">张六的博客</a>
                        <a href="http://juta.wtc.edu.cn/">张六的博客</a>
                        <a href="<?php echo U('/Admin/Manager/login');?>
"></a>
                    </div>
               </div>


                    </div>
               </div>
               <!-- 评论模块结束 -->
		<div class="a" style="width:820px;height:500px;float:left;position:absolute;top:0; overflow-x:auto;padding-right:10px; clear:both" >
			<div id="SOHUCS" sid="" style=""></div>
		</div>  
                                                             
                                                             
                                                             
               <!-- 技术分类开始 -->
         </div>
         <!-- 右侧区域结束 -->
    </div>
    <!-- 正文区域end -->
    <!-- 底部区域开始 -->
    <div class="footer">
        <div class="container">
            <p>
                © 2016-2017 <a href="#">爱前端</a> 注：本站当前使用主题为爱前端独注：本站当前使用主题为爱前端独
                <a target="_blank" href="#">网站地图</a>
            </p>
            <p>注：本站当前使用主题为爱前端独有注：本站当前使用主题为爱前端独有注：本站当前使用主题为爱前端独有注：本站当前使用主题为爱前端独有</p>
        </div>
    </div>
    <!-- 底部区域结束 -->

    <!-- 自定义右键菜单提示开始 -->
    <div id="menu">
         别看啦，宝宝好害羞 <span>*^_^*</span>
    </div>
    <!-- 自定义右键菜单提示结束 -->

    <!-- 首页背景音乐开始 -->
    <!-- <audio src="http://sc1.111ttt.com/2015/1/04/01/97011918297.mp3" autoplay="autoplay" loop="loop" id="music"></audio> -->
    <div class="control hover"></div>
    <!-- 首页背景音乐结束 -->


    <!-- 小飞机start -->
    <div class="aircraft"></div>
    <audio src="<?php echo @MUSIC_URL;?>
h2.mp3" id="audio" loop="loop"></audio>
    <audio src="<?php echo @MUSIC_URL;?>
h1.mp3" id="audio1"></audio>
    <!-- 小飞机end -->

    <script type="text/javascript" src="<?php echo @JS_URL;?>
jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="<?php echo @JS_URL;?>
index.js"></script>
    <script type="text/javascript" src="<?php echo @JS_URL;?>
javascript.js"></script>
    <script>
         $("html").css("overflow","visible");
         //alert($(".continar-left").height());
         $(".a").css("top",$(".continar-left").height()+150);
          document.onmousemove=function(){
               $(".a").css("top",$(".continar-left").height()+150);
                                                 
          }
                                          
        
    </script>
<script id="cy_cmt_num" src="https://changyan.sohu.com/upload/plugins/plugins.list.count.js?clientId=cytjhRbxr">
</script>
      <script type="text/javascript">
     (function(){
var appid = 'cytjhRbxr';
var conf = 'prod_7bd8a2c2f692b42360597b319b069560';
var width = window.innerWidth || document.documentElement.clientWidth;
if (width < 960) {
window.document.write('<script id="changyan_mobile_js" charset="utf-8" type="text/javascript" src="https://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=' + appid + '&conf=' + conf + '"><\/script>'); }
else {
    var loadJs=function(d,a){
        var c=document.getElementsByTagName("head")[0]||document.head||document.documentElement;
    var b=document.createElement("script");
    b.setAttribute("type","text/javascript");
    b.setAttribute("charset","UTF-8");
    b.setAttribute("src",d);
    if(typeof a==="function"){
        if(window.attachEvent){
            b.onreadystatechange=function(){
                var e=b.readyState;
                if(e==="loaded"||e==="complete"){
                    b.onreadystatechange=null;a() } }
                }else{
                        b.onload=a
                    } }
                        c.appendChild(b)};
                        loadJs("https://changyan.sohu.com/upload/changyan.js",function() {
                            window.changyan.api.config({ appid:appid,conf:conf } ) });
                         } })();


</script>
<script class='pMove'>
            move(100);
        </script>
<?php }} ?>