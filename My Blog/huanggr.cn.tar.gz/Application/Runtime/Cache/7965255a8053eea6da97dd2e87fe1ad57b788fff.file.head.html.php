<?php /* Smarty version Smarty-3.1.6, created on 2018-01-31 10:45:44
         compiled from "./Application/Home/View/Index/head.html" */ ?>
<?php /*%%SmartyHeaderCode:601244695a712dd8c341e5-78119000%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7965255a8053eea6da97dd2e87fe1ad57b788fff' => 
    array (
      0 => './Application/Home/View/Index/head.html',
      1 => 1517227324,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '601244695a712dd8c341e5-78119000',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a712dd8cfa50',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a712dd8cfa50')) {function content_5a712dd8cfa50($_smarty_tpl) {?><!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="UTF-8">
		<meta name="format-detection" content="telephone=no" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">
		<meta name="keywords" content="小黄的前端博客,小黄,个人博客,爱前端个人博客,个人博客网站,爱前端，web前端博客，网页制作，博客，HTML5/CSS3，Javascript">
		<meta name="description" content="爱前端个人博客，目前正在持续更新中……">
		<title>小黄的前端博客</title>
		<link rel="stylesheet" href="<?php echo @CSS_URL;?>
index.css">
		<link href="<?php echo @IMG_URL;?>
favicon.ico" rel="shortcut icon" />
		<script language="JavaScript" type="text/javascript">
			if((navigator.userAgent.indexOf('MSIE') >= 0) &&
				(navigator.userAgent.indexOf('Opera') < 0)) {
				alert('你是使用IE');
				window.location.href = "<?php echo U('Index/beta');?>
";
			} else if(navigator.userAgent.indexOf('Firefox') >= 0) {
				//alert('你是使用Firefox')
			} else if(navigator.userAgent.indexOf('Opera') >= 0) {
				//alert('你是使用Opera')
			} else {
				//alert('你是使用其他的浏览器浏览网页！')
			}
			if(window.innerWidth < 600) {
				window.location.href = "http://huanggr.cn/no.html";
			}
		</script>
		<style type="text/css">
			@font-face {
				font-family: 'iconfont';
				/* project id 420292 */
				src: url('//at.alicdn.com/t/font_420292_5dt5v0bwvew89f6r.eot');
				src: url('//at.alicdn.com/t/font_420292_5dt5v0bwvew89f6r.eot?#iefix') format('embedded-opentype'), url('//at.alicdn.com/t/font_420292_5dt5v0bwvew89f6r.woff') format('woff'), url('//at.alicdn.com/t/font_420292_5dt5v0bwvew89f6r.ttf') format('truetype'), url('//at.alicdn.com/t/font_420292_5dt5v0bwvew89f6r.svg#iconfont') format('svg');
			}
			
			.iconfont {
				font-family: "iconfont" !important;
				font-size: 16px;
				font-style: normal;
				-webkit-font-smoothing: antialiased;
				-webkit-text-stroke-width: 0.2px;
				-moz-osx-font-smoothing: grayscale;
			}
			
			#progress {
				position: fixed;
				background: #000;
				top: 0;
				left: 0;
				width: 100%;
				height: 100%;
				z-index: 99999;
			}
			
			#progress p {
				width: 0px;
				height: 30px;
				border-radius: 3px;
				background: #ffcccc;
				color: #330000;
				font-size: 14px;
				font-weight: bold;
				line-height: 30px;
				text-align: center;
				overflow: hidden;
				font-family: 'Microsoft yahei';
				position: absolute;
				top: 50%;
				left: 50%;
				margin-top: -15px;
				margin-left: -250px;
			}
			
			body {
				//overflow:hidden;
			}
		</style>

	</head>

	<body>
		<div id='progress'>
			<p>0%</p>
		</div>
		<script>
			var oP = document.getElementById('progress').getElementsByTagName('p')[0];
			var oCss = document.getElementById('css');

			function move(num) {
				clearInterval(oP.timer);
				oP.timer = setInterval(function() {
					if(parseInt(oP.innerHTML) < num) {
						var s = parseInt(oP.innerHTML) + 1;
						var w = 500 * s / 100;
						oP.innerHTML = s + '%';
						oP.style.width = w + 'px';
					} else {
						clearInterval(oP.timer);
						if(num == 100) {
						 clearInterval( oP.timer );
                			if ( num == 100 )
                			{
                 				$('#progress').remove();
                			}
						}
					}
				}, 10);
			};
		</script>

		<!-- IE禁止页面快捷保存，导致盗窃 -->
		<noscript><iframe src=*></iframe></noscript>
		<!-- 头部start -->
		<div class="header">
			<div class="header-conter">
				<div class="topbar">
					<ul>
						<li>
							<a href="<?php echo U('User/login');?>
" target="_blank">&nbsp;<i class="iconfont">&#xe6e3;</i>&nbsp;您好，请登录</a>
						</li>
						<li>
							<a href="<?php echo U('User/register');?>
" target="_blank">&nbsp;<i class="iconfont">&#xe6e2;</i>&nbsp;注册</a>
						</li>
						<li>
							<a href="javascript:;" target="_blank">特别鸣谢</a>
						</li>
						<li>
							<a href="#" target="_blank">友情链接</a>
						</li>
						<li>
							<a href="<?php echo U('Index/about');?>
" target="_blank">联系我们</a>
						</li>
						<li>
							<a href="http://huanggr.cn/shuo" target="_blank">留言板（哈哈）</a>
						</li>
					</ul>
				</div>
				<div class="nav">
					<a href="http://www.huanggr.cn" class="t-logo" id="Logo">
						<span class="logo"></span>
						<ul id="dj">
							<li></li>
							<li></li>
							<li></li>
						</ul>
					</a>
					<div class="nav-left"></div>
					<div class="brand">
						<p>关注前端开发</p>
						<p>HTML5、CSS3、Javascript</p>
					</div>
					<ul class="music-nav">
						<li detaName="do">
							<a href="index.html">
								<span class="hover">首页</span>
								<span class="hover">首页</span>
							</a>
							<video src="<?php echo @MUSIC_URL;?>
do.mp3"></video>
						</li>
						<li detaName="re">
							<a href="http://www.thinkphp.cn/" target="_blank">
								<span>Thinkphp</span>
								<span>Thinkphp</span>
							</a>
							<video src="<?php echo @MUSIC_URL;?>
re.mp3"></video>
						</li>
						<li detaName="mi" class="front">
							<a href="#">
								<span>前端开发<i class="fa fa-angle-down"></i></span>
								<span>前端开发<i class="fa fa-angle-down"></i></span>
							</a>
							<video src="<?php echo @MUSIC_URL;?>
mi.mp3"></video>
						</li>
						<li detaName="fa">
							<a href="<?php echo U('Index/say');?>
">
								<span>更新提示</span>
								<span>更新提示</span>
							</a>
							<video src="<?php echo @MUSIC_URL;?>
fa.mp3"></video>
						</li>
						<li detaName="sol" class="works">
							<a href="#">
								<span>作品案例<i class="fa fa-angle-down"></i></span>
								<span>作品案例<i class="fa fa-angle-down"></i></span>
							</a>
							<video src="<?php echo @MUSIC_URL;?>
"></video>
						</li>
						<li detaName="la">
							<a href="<?php echo U('Index/message');?>
">
								<span>给我留言</span>
								<span>给我留言</span>
							</a>
							<video src="<?php echo @MUSIC_URL;?>
"></video>
						</li>
						<li detaName="si">
							<a href="<?php echo U('Index/about');?>
">
								<span>关于我</span>
								<span>关于我</span>
							</a>
							<video src="<?php echo @MUSIC_URL;?>
"></video>
						</li>
					</ul>
					<div class="nav-min">
						<!-- <a href="">DIV+CSS</a>
                                    <a href="">jS/jQuery</a>
                                    <a href="">HTML5+CSS3</a> -->
					</div>
					<div class="nav-min nav-min-1">
						<a href="http://www.huanggr.cn/htmlFile/01/index.php">Bootstrap</a>
						<a href="">暂定</a>
						<a href="">暂定</a>
					</div>
					<!-- 搜索按钮开始 -->
					<div class="navto-search">
						<a href="javascript:;" class="search-show active">
							<i class="fa fa-search"></i>
						</a>
					</div>
					<!-- 搜索按钮结束 -->
				</div>
			</div>
			<!-- 搜索区域开始 -->
			<div class="site-search active">
				<div class="container">
					<form method="get" class="site-search-form" action="#">
						<input class="search-input" name="s" type="text" placeholder="输入关键字搜索"><button class="search-btn" type="submit"><i class="fa fa-search"></i></button>
					</form>
				</div>
			</div>
			<!-- 搜索区域结束 -->
		</div>
		<!-- 头部end -->
      
		<script class='pMove'>
			move(33);
		</script><?php }} ?>