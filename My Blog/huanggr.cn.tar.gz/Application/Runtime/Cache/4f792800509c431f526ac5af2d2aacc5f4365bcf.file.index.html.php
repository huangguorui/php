<?php /* Smarty version Smarty-3.1.6, created on 2018-02-02 15:32:20
         compiled from "./Application/Admin/View/Index/index.html" */ ?>
<?php /*%%SmartyHeaderCode:17735147395a741404c78f07-72688331%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4f792800509c431f526ac5af2d2aacc5f4365bcf' => 
    array (
      0 => './Application/Admin/View/Index/index.html',
      1 => 1512822924,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17735147395a741404c78f07-72688331',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a741404cfa3a',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a741404cfa3a')) {function content_5a741404cfa3a($_smarty_tpl) {?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Document</title>

</head>
<body>
    <h1>后台控制主面板</h1>
<dl>
	<dt>这里是模块预览（博客文章管理模块）</dt>
	<dd><a href='<?php echo U("Goods/tianjia?id=29");?>
'>添加文章</a></dd>

	<dd><a href='<?php echo U("Goods/showlist");?>
'>全部文章+查看+删除+修改</a></dd>

</dl>
<hr />
<br />
	<a href="<?php echo @__MODULE__;?>
/Manager/logout" onclick="if(confirm('确定要退出吗？'))return true;else return false" target="_top">安全退出</a>

</body>
</html><?php }} ?>