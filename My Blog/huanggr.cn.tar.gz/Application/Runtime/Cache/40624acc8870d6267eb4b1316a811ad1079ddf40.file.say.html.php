<?php /* Smarty version Smarty-3.1.6, created on 2018-02-01 08:23:39
         compiled from "./Application/Home/View/Index/say.html" */ ?>
<?php /*%%SmartyHeaderCode:15692091805a725e0b592444-91210037%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '40624acc8870d6267eb4b1316a811ad1079ddf40' => 
    array (
      0 => './Application/Home/View/Index/say.html',
      1 => 1512809462,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15692091805a725e0b592444-91210037',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5a725e0b68bbb',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a725e0b68bbb')) {function content_5a725e0b68bbb($_smarty_tpl) {?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>我的微博-心情小镇</title>
<link rel="stylesheet" type="text/css" href="<?php echo @CSS_URL;?>
say.css">
</head>
<body>
<div id="message">
	<header id="header">心情小镇</header>
    <ul id="messageList">
    	<!--<li>
        	<div class="box">
            	<div class="pic"></div>
                <div class="ico"></div>
                <div class="content text">学习课程</div>
                <div class="reply text">好好学习，天天做出好东西~~</div>
            </div>
        </li>-->
    </ul>
    <footer id="footer">
    	<!--<a href="javascript:;">首页</a><a href="javascript:;" >上一页</a><p><a href="javascript:;" class="active">1</a><a href="javascript:;">2</a><a href="javascript:;">3</a></p><a href="javascript:;">下一页</a><a href="javascript:;">末页</a>-->
	</footer>
</div>
<script src="<?php echo @JS_URL;?>
date.js"></script>
<script>
var iPage=8;
var iNow=0;
createFoot();
function createFoot()
{
	var oFooter=document.getElementById("footer");
	var iLenght=Math.ceil(date.length/iPage);
	var sHtml='<a href="javascript:;">首页</a><a href="javascript:;" >上一页</a><p>';
	for(var i=0;i<iLenght;i++)
	{
		sHtml+='<a href="javascript:;">'+(i+1)+'</a>';
	}
	sHtml+='</p><a href="javascript:;">下一页</a><a href="javascript:;">末页</a>';
	oFooter.innerHTML=sHtml;
	var aA=oFooter.getElementsByTagName("a");
	var oP=oFooter.getElementsByTagName("p")[0];
	var aBtns=oP.getElementsByTagName("a");
	for(var i=0;i<aBtns.length;i++)
	{
		(function(a){
			aBtns[a].onclick=function()
			{
				footerHide(a);
			};
		})(i);
	}
	aA[0].onclick=function()
	{
		footerHide(0);
	};
	aA[1].onclick=function()
	{
		footerHide(iNow-1);
	};
	aA[aA.length-2].onclick=function()
	{
		footerHide(iNow+1);
	};
	aA[aA.length-1].onclick=function()
	{
		footerHide(aBtns.length-1);
	};
	create(0);
}
function create(iNub)
{
	var oList=document.getElementById("messageList");
	var sHtml="";
	var iStart=iNub*iPage;
	var iEnd=iStart+iPage;
	iEnd=iEnd>date.length?date.length:iEnd;
	for(var i=iStart;i<iEnd;i++)
	{
		sHtml+='<li><div class="box"><div class="pic"></div><div class="ico"></div><div class="content text">'+date[i].message+'</div><div class="reply text">'+date[i].reply+'</div></div></li>';
	}
	oList.innerHTML=sHtml;
	footerShow(iNub);
}
function footerHide(iNub)
{
	var oFooter=document.getElementById("footer");
	var aA=oFooter.getElementsByTagName("a");
	for(var i=0;i<aA.length;i++)
	{
		aA[i].style.opacity=0;
		aA[i].addEventListener("webkitTransitionEnd",function(ev){
			 ev.cancelBubble=true;
		},false);
	}
	oFooter.style.transition=".5s .5s";
	oFooter.addEventListener("webkitTransitionEnd",end,false);
	oFooter.style.marginTop="50px";
	oFooter.style.opacity=0;
	function end(e)
	{
		this.removeEventListener("webkitTransitionEnd",end,false);
		//console.log(e,e.type,e.propertyName);
		listHide(iNub);
	}
}
function listHide(iNub)
{
	var oList=document.getElementById("messageList");
	var oFooter=document.getElementById("footer");
	var aLi=oList.children;
	for(var i=0;i<aLi.length;i++)
	{
		aLi[i].style.transition=".5s "+(aLi.length-1)*100+"ms";
		aLi[i].style.opacity=0;
		aLi[i].style.marginTop="50px";
		aLi[i].addEventListener("webkitTransitionEnd",function(ev){
			 ev.cancelBubble=true;
		},false);
	}
	oList.style.transition="1s .5s";
	oList.style.height="0px";
	oFooter.style.transition=".5s 1.5s";
	oFooter.style.opacity=1;
	oFooter.style.marginTop="0";
	oList.addEventListener("webkitTransitionEnd",end,false);
	function end()
	{
		this.removeEventListener("webkitTransitionEnd",end,false);
		create(iNub);
	};
}
function footerShow(iNub)
{
	var oFooter=document.getElementById("footer");
	var aA=oFooter.getElementsByTagName("a");
	var oP=oFooter.getElementsByTagName("p")[0];
	var aBtns=oP.getElementsByTagName("a");
	aBtns[iNow].className="";
	iNow=iNub;
	aBtns[iNow].className="active";
	if(iNow==0)
	{
		aA[0].style.display="none";
		aA[1].style.display="none";
	}
	else
	{
		aA[0].style.display="inline-block";
		aA[1].style.display="inline-block";
	}
	if(iNow==aBtns.length-1)
	{
		aA[aA.length-1].style.display="none";
		aA[aA.length-2].style.display="none";
	}
	else
	{
		aA[aA.length-1].style.display="inline-block";
		aA[aA.length-2].style.display="inline-block";
	}
	for(var i=0;i<aA.length;i++)
	{
		aA[i].style.opacity=1;
	}
	 showList();
}
function showList()
{
	var oList=document.getElementById("messageList");
	var iHeight=0;
	var aLi=oList.children;
	for(var i=0;i<aLi.length;i++)
	{
		iHeight+=aLi[i].offsetHeight;
		aLi[i].off=true;
	}
	oList.style.height=iHeight+"px";
	oList.addEventListener("webkitTransitionEnd",end,false);
	function end()
	{
		oList.removeEventListener("webkitTransitionEnd",end,false);
		showLi();
		window.onresize=window.onscroll=function()
		{
			showLi();
		};
	}
}
function showLi()
{
	var oList=document.getElementById("messageList");
	var aLi=oList.children;
	var iTop=document.body.scrollTop+document.documentElement.clientHeight;
	var iTime=0;
	for(var i=0;i<aLi.length;i++)
	{
		if(getTop(aLi[i])<iTop && aLi[i].off)
		{
			aLi[i].off=false;
			openLi(aLi[i],iTime);
			iTime+=100;
		}
	}
}
function openLi(obj,iTime)
{
	var oBox=obj.children[0];
	var oReply=oBox.children[oBox.children.length-1];
	oBox.addEventListener("webkitTransitionEnd",end,false);
	setTimeout(function(){
		oBox.style.WebkitTransform="rotateY(0deg)";
	},iTime);
	function end()
	{
		this.removeEventListener("webkitTransitionEnd",end,false);
		oReply.style.opacity=1;
		oReply.style.WebkitTransform="rotateX(0deg)";
	};
}
function getTop(obj)
{
	var iTop=0;
	while(obj)
	{
		iTop+=obj.offsetTop;
		obj=obj.offsetParent;
	}
	return iTop;
}
</script>
</body>
</html>
<?php }} ?>