<?php
//Goods模型model类

namespace Model;
use Think\Model;
//GoodsModel继承了model的属性
class NewsModel extends Model{

}