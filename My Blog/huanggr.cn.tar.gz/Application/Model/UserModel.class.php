<?php
//Goods模型model类

namespace Model;
use Think\Model;
class UserModel extends Model{

//批处理方式来处理验证
protected $patchValidate = true;

    //设置验证规则,这个是父类model的属性

protected $_validate =array(
//array(字段名称 表单域name属性值，验证规则，错误提示[，验证条件，附加规则，验证时间])
        array('username','require','用户名不能为空'),
        array('username','','用户名已经被占用',0,'unique'),
        //② 密码，非空
        array('password','require','密码不能为空'),
        //③ 确认密码，非空/与密码保持一致
        array('password2','require','确认密码不能为空'),
        array('password2','password','与密码保持一致',0,'confirm'),
        //④ 邮箱验证,符合邮箱格式
        array('user_email','email','邮箱格式不正确',2),
        array('user_qq','5,11','电话格式不正确',2,"length"),



    );


}