<?php
//Goods模型model类

namespace Model;
use Think\Model;
//GoodsModel继承了model的属性
class EnglishModel extends Model{
    // 实际数据表名（包含表前缀）
    protected $trueTableName    =   'english';
}