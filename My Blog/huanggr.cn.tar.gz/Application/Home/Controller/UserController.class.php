<?php
namespace Home\Controller;
use Think\Controller;
use Think\Verify;
class UserController extends Controller {
	function login() {
		$user = new \Model\UserModel();
		if (!empty($_POST)) {
		//dump($_POST);
			if(!empty($_POST))
			//校验码
			$vry = new Verify();

			if($vry -> check($_POST['yanzheng'])){
				//echo "验证码是对的";
				$username = $_POST["username"];
				$password = $_POST["password"];

			$user -> where("username ='$username' and password='$password'");
			$a = $user -> select();
			//调试看是否有值
			//dump($a);
			if ($a) {
				//echo "成功";

				$this -> redirect('Index/index', 0, 3, '恭喜您，您已经登录成功了');
				$this -> display();
			} else {
				//dump($user -> getError());
				//最后需要显示在模板中
				echo "<p style='text-align:center;font-size:30px'>账号或密码输入错误</p>";
				$this -> display();
			}
			}else{
				echo "验证码是错的";

			}



		}
		$this -> display();

	}

	//注册系统
	function register() {
		//两个逻辑，展示，收集
		//由于表单验证调用的是model下面的属性，所以实例化model对象
		//$user = D('user');
		$user = new \Model\UserModel();
		if (!empty($_POST)) {
			//dump($_POST);
			//此句话有问题
			//$_POST['username'] = implode(',',$_POST['username']);
			//$z = $user -> add($_POST);
			//echo $z;

			$data = $user -> create();

			//dump($data);
			if ($data) {
				//验证成功，就会通过$data体现收集到的表单信息,implode将数据转换为字符串
				//$data['username'] = implode(',',$data['username']);

				//z表示id
				$z = $user -> add($data);
				//echo $z;

				if ($z) {
					//echo "表示成功了";
				$this -> redirect('User/register', array("id" => $id), 5, '您已经注册成功了，请登录');

				}
			} else {
				//验证失败,输出查看错误信息，
				//dump($user -> getError());

				//最后需要显示在模板中
				$user -> getError();
				$this -> assign("errorInfo", $user -> getError());
				$this -> display();

			}

		} else {
			$this -> display();
		}

	}

	//生成验证码
	function verifyImg(){
		$cfg = array(
			'imageH' => 40,
			'imageW' => 130,
			'length' =>4,
			'fontSize' => 16,
			'fontttf' => '4.ttf',


		);
		$very = new \Think\Verify($cfg);
		$very -> entry();

	}





}
