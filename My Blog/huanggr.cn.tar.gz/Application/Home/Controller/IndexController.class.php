<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
     function index(){
$goods = D('news');

        $cnt = $goods -> count(); //获得总条数，sum, max.avg min

        $per = 6;
        //echo $cnt;

        //2.实例化分页类对象
        $page_obj = new \Tools\Page($cnt,$per);

        //3.制作一条sql语句
        //$page_obj -> limit:分页工具类会根据当前页面把limit，偏移量，长度给封装好
        $sql = "select * from tb_news order by id desc ".$page_obj ->limit;

        $info = $goods ->query($sql);
        //4.制作页码列表,根据数组传入的值进行循环
        $pagelist = $page_obj -> fpage(array(3,4,5,6,7,8));

        $this -> assign('pagelist',$pagelist);
        $this -> assign('info', $info);


        $this -> display('head');

        $this -> display('index');
        $this -> display('Foot');

    }

 function details($id){
        $goods = D('news');
        if (!empty($_POST)) {
           // dump($_POST);
           echo "读取数据库失败";

        } else {
            //方法一
            //find()方法，通过一位数组返回一条记录信息
            $info = $goods -> find($id);
            ////////////////////加1，写在这里

            $count = $goods->where("id=$id")->getField('browse');
            $data['browse'] = $count + 1;
            $goods->where("id=$id")->save($data);
            $this -> assign('info', $info);
        }
        $this -> display('head');
        $this -> display('details');
        $this -> display('foot');
    }


    function message(){

         $this -> display('head');
        $this->display('message');

        $this -> display('foot');
    }
    function about(){
         $this -> display('head');
        $this->display('about');
        $this -> display('Foot');

    }
    function beta(){
         $this -> display('beta');

    }
    function say(){
        $this->display('say');
    }
}