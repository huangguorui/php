<?php
namespace Home\Controller;
use Think\Controller;
class ManagerController extends Controller {
	function login() {

		$this -> display();

	}

}
