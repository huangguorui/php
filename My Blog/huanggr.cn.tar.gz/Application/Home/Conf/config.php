<?php
return array(
	//'配置项'=>'配置值'

       'DB_TYPE'               =>  'mysql',     // 数据库类型
    'DB_HOST'               =>  'localhost', // 服务器地址
    'DB_NAME'               =>  'dd_bllog',          // 数据库名
    'DB_USER'               =>  'dd_bllog',      // 用户名
    'DB_PWD'                =>  '123456',          // 密码
    'DB_PORT'               =>  '3306',        // 端口
    'DB_PREFIX'             =>  'tb_',    // 数据库表前缀

  
  
  
  
/*定义的常量，需要的时候直接可以使用*/

define('CSS_URL', 'http://huanggr.cn/Public/css/' ),
define('IMG_URL', 'http://huanggr.cn/Public/images/'),
define('JS_URL', 'http://huanggr.cn/Public/js/'),
define('MUSIC_URL', 'http://huanggr.cn/Public/mp3/'),
define('moban', 'http://huanggr.cn/'),
    //开启模板smrt引擎
    'TMPL_ENGINE_TYPE'      =>  'smarty',     // 默认模板引擎 以下设置仅对使用Think模板引擎有效

    /*使用smarty换标签*/
'TMPL_ENGINE_CONFIG'=>array(
    //'left_delimiter' => '<%%%',
    //'right_delimiter'=> '%%%>',
    ),
  
  
'URL_ROUTER_ON'   => true, //开启路由
'URL_ROUTE_RULES' => array( //定义路由规则 
	'new/:id\d'    => 'Home/Index/details',
),


  
);