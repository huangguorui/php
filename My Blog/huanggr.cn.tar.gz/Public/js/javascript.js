window.onload = function(){}
    //禁止鼠标右键功能，自定义菜单开始
/*            var mBenu = document.getElementById('menu');
            document.oncontextmenu = function(ev) {
                var ev = ev || event;
                mBenu.style.display = 'block';
                mBenu.style.left = ev.pageX-85 + 'px';
                mBenu.style.top = ev.pageY-24 + 'px';
                return false;
            }
            document.onclick = function() {
                mBenu.style.display = 'none';
            }*/
    //禁止鼠标右键功能，自定义菜单结束
/*
                            //首页头部导航动画加载
                            $(".continar .continar-left").css("WebkitTransform","translateY(-108px)");
                            $(".continar .continar-left").css("MsTransform","translateY(-108px)");
                            $(".header").css("WebkitAnimation","Top 2s cubic-bezier(.76,1.93,.73,.35)");
                            $(".header").css("MsAnimation","Top 2s cubic-bezier(.76,1.93,.73,.35)");
                            setTimeout(function(){
                                $(".header").css("WebkitTransform","translateY(0px)");
                                $(".header").css("MsTransform","translateY(0px)");
                                //alert(1)
                            },1800);
                                var oLi = $('#dj li')[0];
                                $(".t-logo").mouseover(function(){
                                    $('#dj li').css("WebkitAnimation","");
                                    $('#dj li').css("MsAnimation","");
                                });
                            //首页开场左侧动画偏移量
                            $(".continar .continar-left").css("WebkitTransform","translateX(-1100px)");
                            $(".continar .continar-left").css("WebkitAnimation","playLeft 2.5s 1s ease-in-out");
                            $(".continar .continar-left").css("MsAnimation","playLeft 2.5s 1s ease-in-out");
                            setTimeout(function(){
                                $(".continar .continar-left").css("WebkitTransform","translateX(0px)");
                            },1500);
  
  							 $(".a").css("WebkitTransform","translateX(-1100px)");
                            $(".a").css("WebkitAnimation","playLeft 2.5s 1s ease-in-out");
                            $(".a").css("MsAnimation","playLeft 2.5s 1s ease-in-out");
                            setTimeout(function(){
                                $(".a").css("WebkitTransform","translateX(0px)");
                            },1500);
  
                            //首页开场右侧动画偏移量
                            $(".continar-right").css("WebkitTransform","translateX(435px)");
                            $(".continar-right").css("MsTransform","translateX(435px)");
                            $(".continar-right").css("WebkitAnimation","playRight 1.5s .5s ease-in-out");
                            $(".continar-right").css("MsAnimation","playRight 1.5s .5s ease-in-out");


                            setTimeout(function(){
                                $(".continar-right").css("WebkitTransform","translateX(0px)");
                                $(".continar-right").css("MsTransform","translateX(0px)");
                            },1000);

                        }
                            //开场背景音乐
                            //$("#music").get(0).play();*/


